var MyFunction = function()
{
	var message = "";
	var message = message + "ProductID: " + this.ProductID + "<br />";
	var message = message + "ProductName: " + this.ProductName +"<br />";
	var message = message + "UnitPrice: " + this.UnitPrice + "<br />"
	message = message + "<br />";
	return message;
}

var sorterID = function(x,y)
{
	var answer = x.ProductID - y.ProductID;
	if(answer >0)
	{
		answer = 1
	}

	else if(answer < 1)
	{
		answer = -1;
	}

	else
	{
		answer = 0;
	}
	return answer;
}

var reverseID = function(x,y)
{
	var answer = x.ProductID-y.ProductID;
	if(answer >0)
	{
		answer = -1
	}

	else if(answer < 1)
	{
		answer = 1;
	}

	else
	{
		answer = 0;
	}
	return answer;
}

var sorterName = function(x,y)
{
	var answer;
	if(x.ProductName > y.ProductName)
	{
		answer = 1
	}

	else if(x.ProductName < y.ProductName)
	{
		answer = -1;
	}

	else
	{
		answer = 0;
	}
	return answer;
}

var reverseName = function(x,y)
{
	var answer;
	if(x.ProductName > y.ProductName)
	{
		answer = -1
	}

	else if(x.ProductName < y.ProductName)
	{
		answer = 1;
	}

	else
	{
		answer = 0;
	}
	return answer;
}

var sorterPrice = function(x,y)
{
	var answer = x.UnitPrice-y.UnitPrice;
	if(answer >0)
	{
		answer = 1
	}

	else if(answer < 1)
	{
		answer = -1;
	}

	else
	{
		answer = 0;
	}
	return answer;
}

var reversePrice = function(x,y)
{
	var answer = x.UnitPrice -y.UnitPrice
	if(answer >0)
	{
		answer = -1
	}

	else if(answer < 1)
	{
		answer = 1;
	}

	else
	{
		answer = 0;
	}
	return answer;
}
function Product(aProductID,aProductName,aUnitPrice)
{
	this.ProductID = aProductID;
	this.ProductName = aProductName;
	this.UnitPrice = aUnitPrice;
	this.toString = MyFunction;
}

var ProductArray = [];
ProductArray[0]= new Product(1,"Chai",18);
ProductArray[1]= new Product(2,"Chang",19);
ProductArray[2]= new Product(3,"Aniseed Syrup",10);
ProductArray[3]= new Product(4,"Chef Anton's Cajun Seasoning",22);
ProductArray[4]= new Product(5,"Chef Anton's Gumbo Mix",21.35);
ProductArray[5]= new Product(6,"Grandma's Boysenberry Spread",25);
ProductArray[6]= new Product(7,"Uncle Bob's Organic Dried Pears",30);
ProductArray[7]= new Product(8,"Northwoods Cranberry Sauce",40);
ProductArray[8]= new Product(9,"Mishi Kobe Niku",97);
ProductArray[9]= new Product(10,"Ikura",31);
ProductArray[10]= new Product(11,"Queso Cabrales",21);
ProductArray[11]= new Product(12,"Queso Manchego La Pastora",38);
ProductArray[12]= new Product(13,"Konbu",6);
ProductArray[13]= new Product(14,"Tofu",23.25);
ProductArray[14]= new Product(15,"Genen Shouyu",15.5);
ProductArray[15]= new Product(16,"Pavlova",17.45);
ProductArray[16]= new Product(17,"Alice Mutton",39);
ProductArray[17]= new Product(18,"Carnarvon Tigers",62.5);
ProductArray[18]= new Product(19,"Teatime Chocolate Biscuits",9.2);
ProductArray[19]= new Product(20,"Sir Rodney's Marmalade",81);
ProductArray[20]= new Product(21,"Sir Rodney's Scones",10);
ProductArray[21]= new Product(22,"Gustaf's Knäckebröd",21);
ProductArray[22]= new Product(23,"Tunnbröd",9);
ProductArray[23]= new Product(24,"Guaraná Fantástica",4.5);
ProductArray[24]= new Product(25,"NuNuCa Nuß-Nougat-Creme",14);
ProductArray[25]= new Product(26,"Gumbär Gummibärchen",31.23);
ProductArray[26]= new Product(27,"Schoggi Schokolade",43.9);
ProductArray[27]= new Product(28,"Rössle Sauerkraut",45.6);
ProductArray[28]= new Product(29,"Thüringer Rostbratwurst",123.79);
ProductArray[29]= new Product(30,"Nord-Ost Matjeshering",25.89);
ProductArray[30]= new Product(31,"Gorgonzola Telino",12.5);
ProductArray[31]= new Product(32,"Mascarpone Fabioli",32);
ProductArray[32]= new Product(33,"Geitost",2.5);
ProductArray[33]= new Product(34,"Sasquatch Ale",14);
ProductArray[34]= new Product(35,"Steeleye Stout",18);
ProductArray[35]= new Product(36,"Inlagd Sill",19);
ProductArray[36]= new Product(37,"Gravad lax",26);
ProductArray[37]= new Product(38,"Côte de Blaye",263.5);
ProductArray[38]= new Product(39,"Chartreuse verte",18);
ProductArray[39]= new Product(40,"Boston Crab Meat",18.4);
ProductArray[40]= new Product(41,"Jack's New England Clam Chowder",9.65);
ProductArray[41]= new Product(42,"Singaporean Hokkien Fried Mee",14);
ProductArray[42]= new Product(43,"Ipoh Coffee",46);
ProductArray[43]= new Product(44,"Gula Malacca",19.45);
ProductArray[44]= new Product(45,"Røgede sild",9.5);
ProductArray[45]= new Product(46,"Spegesild",12);
ProductArray[46]= new Product(47,"Zaanse koeken",9.5);
ProductArray[47]= new Product(48,"Chocolade",12.75);
ProductArray[48]= new Product(49,"Maxilaku",20);
ProductArray[49]= new Product(50,"Valkoinen suklaa",16.25);
ProductArray[50]= new Product(51,"Manjimup Dried Apples",53);
ProductArray[51]= new Product(52,"Filo Mix",7);
ProductArray[52]= new Product(53,"Perth Pasties",32.8);
ProductArray[53]= new Product(54,"Tourtière",7.45);
ProductArray[54]= new Product(55,"Pâté chinois",24);
ProductArray[55]= new Product(56,"Gnocchi di nonna Alice",38);
ProductArray[56]= new Product(57,"Ravioli Angelo",19.5);
ProductArray[57]= new Product(58,"Escargots de Bourgogne",13.25);
ProductArray[58]= new Product(59,"Raclette Courdavault",55);
ProductArray[59]= new Product(60,"Camembert Pierrot",34);
ProductArray[60]= new Product(61,"Sirop d'érable",28.5);
ProductArray[61]= new Product(62,"Tarte au sucre",49.3);
ProductArray[62]= new Product(63,"Vegie-spread",43.9);
ProductArray[63]= new Product(64,"Wimmers gute Semmelknödel",33.25);
ProductArray[64]= new Product(65,"Louisiana Fiery Hot Pepper Sauce",21.05);
ProductArray[65]= new Product(66,"Louisiana Hot Spiced Okra",17);
ProductArray[66]= new Product(67,"Laughing Lumberjack Lager",14);
ProductArray[67]= new Product(68,"Scottish Longbreads",12.5);
ProductArray[68]= new Product(69,"Gudbrandsdalsost",36);
ProductArray[69]= new Product(70,"Outback Lager",15);
ProductArray[70]= new Product(71,"Fløtemysost",21.5);
ProductArray[71]= new Product(72,"Mozzarella di Giovanni",34.8);
ProductArray[72]= new Product(73,"Röd Kaviar",15);
ProductArray[73]= new Product(74,"Longlife Tofu",10);
ProductArray[74]= new Product(75,"Rhönbräu Klosterbier",7.75);
ProductArray[75]= new Product(76,"Lakkalikööri",18);
ProductArray[76]= new Product(77,"Original Frankfurter grüne Soße",13);

var myJson = JSON.stringify(ProductArray);
alert(myJson);
//ProductArray.sort(reverseID);
//for(var i = 0; i < ProductArray.length;i++)
//{ 
	//document.write(ProductArray[i]);
//}
